#include "utils.h"
#include "stack.h"
#include "queue.h"

bool isNotStop(const char *word);
void readInputIn(Queue *queue,FILE * file);
void processInput(Queue *queue, Stack *results);
