#include "utils.h"

int main()
{
    /**
    * * Puteti sa folositi acest main pentru a testa bucatile pe cod pe care le implementati.
    * * Folositi date din ..data/input.txt sau direct fisierul TEST_FILE (definit in utils.h)
    * * Pentru verificare puteti folosi comanda make single-run
    */
}
